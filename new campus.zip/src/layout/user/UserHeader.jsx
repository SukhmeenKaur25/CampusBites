import { Link } from "react-router-dom"
import { useNavigate } from "react-router-dom"
import AuthServices from "../../services/AuthServices"
import Swal from "sweetalert2"
import { toast } from "react-toastify"
import { FaCartPlus } from "react-icons/fa";

function UserHeader() {
  let isLogin = AuthServices.getIslogin()

  const nav = useNavigate()

  const Logout = () => {


    Swal.fire({
      title: "Are you sure?",
      // text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, Logout !"
    }).then((result) => {
      if (result.isConfirmed) {
        AuthServices.clear()
        toast.info("Logout")
        nav("/login")
        Swal.fire({
          title: "Logout!",
          // text: "Your file has been deleted.",
          icon: "success"
        });
      }
    });
  }
  return (
    <>
      <div id="topbar">
        <div className="container">
          <div className="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div className="top-contact d-flex flex-wrap">
              <span>
                <i className="fas fa-phone-alt" />
                +1 9456823145
              </span>
              <span>
                <i className="fas fa-envelope" />
                campusbites.com
              </span>
              <span>
                <i className="fas fa-map-marker-alt" />
                DAV Institute of Engineering & Technology, Jalandhar
              </span>
            </div>
            <div className="d-flex align-items-center gap-3">
              <span className="ttag">
                <i className="fas fa-fire me-1" />
                20 MIN CAMPUS DELIVERY!
              </span>
              <div className="tsoc">
                <Link to="/">
                  <i className="fab fa-facebook-f" />
                </Link>
                <Link to="/">
                  <i className="fab fa-instagram" />
                </Link>
                <Link to="/">
                  <i className="fab fa-tiktok" />
                </Link>
                <Link to="/">
                  <i className="fab fa-youtube" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* ============================================================
   NAVBAR
   ============================================================ */}
      <nav className="navbar navbar-expand-lg" id="nav">
        <div className="container">
          <Link className="navbar-brand" to="#">
            <div className="blogo">
              <div className="bico">
                <i className="fas fa-utensils" />
              </div>
              <div>
                <div className="bname">
                  Campus<span>Bites</span>
                </div>
                <div className="bsub">CAMPUS FOOD, DELIVERED</div>
              </div>
            </div>
          </Link>
          <button
            className="navbar-toggler border-0"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navmenu"
          >
            <i
              className="fas fa-bars"
              style={{ color: "var(--primary)", fontSize: "1.35rem" }}
            />
          </button>
          <div className="collapse navbar-collapse" id="navmenu">
            <ul className="navbar-nav mx-auto">
              <li className="nav-item">
                <Link className="nav-link active" to="/">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/about">
                  About
                </Link>
              </li>
              {/* <li className="nav-item">
                <Link className="nav-link" to="/chefs">
                  Chefs
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/reservation">
                  Reservation
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/testimonials">
                  Reviews
                </Link>
              </li> */}
              <li className="nav-item">
                <Link className="nav-link" to="/contact">
                  Contact
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/menu">
                  Menu
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/viewCategory">
                  View Category
                </Link>
              </li>

              {/* <li className="nav-item">
                <Link className="nav-link" to="/viewMenu">
                  View Menu
                </Link>
              </li> */}
              {
                isLogin ? (
                  <li className="nav-item d-flex align-items-center">
                    <button
                      className="nav-cta btn btn-outline-danger border-danger bg-white text-danger"
                      
                      onClick={Logout}
                    >
                      Logout
                    </button>
                  </li>
                ) : (
                  <>
                    <li className="nav-item">
                      <Link className="nav-link" to="/login">
                        Login
                      </Link>
                    </li>

                    <li className="nav-item">
                      <Link className="nav-link" to="/register">
                        Register
                      </Link>
                    </li>
                  </>
                )
              }
            </ul>
            <div className="d-flex align-items-center gap-1">
                <Link to="/addToCart" className="nav-link nav-cta">
                <FaCartPlus size={22} />
              </Link>
              <Link to="/orders" className="nav-link nav-cta">
                <i className="fas fa-shopping-bag me-1" />
                My orders
              </Link>
            </div>
          </div>
        </div>
      </nav>
      {/* ============================================================
   FIX 1 � SEARCH OVERLAY POPUP
   ============================================================ */}
      <div id="searchOv">
        <button className="sovclose" id="searchClose">
          <i className="fas fa-times" />
        </button>
        <div className="sovbox">
          <h4>What are you craving today?</h4>
          <div className="sovinput">
            <input
              type="text"
              id="searchInput"
              placeholder="Search burgers, pizza, chicken..."
              autoComplete="off"
            />
            <button>
              <i className="fas fa-search" />
            </button>
          </div>
          {/* Categories inside search box */}
          <div className="sovcats">
            <div className="sovcat active" data-cat="all">
              <img src="img/menu/1.jpg" alt="" />
              All Items
            </div>
            <div className="sovcat" data-cat="burgers">
              <img src="img/menu/1.jpg" alt="" />
              Burgers
            </div>
            <div className="sovcat" data-cat="pizza">
              <img src="img/menu/2.jpg" alt="" />
              Pizza
            </div>
            <div className="sovcat" data-cat="chicken">
              <img src="img/menu/3.jpg" alt="" />
              Chicken
            </div>
            <div className="sovcat" data-cat="wraps">
              <img src="img/menu/4.jpg" alt="" />
              Wraps
            </div>
            <div className="sovcat" data-cat="pasta">
              <img src="img/menu/5.jpg" alt="" />
              Pasta
            </div>
            <div className="sovcat" data-cat="desserts">
              <img src="img/menu/6.jpg" alt="" />
              Desserts
            </div>
          </div>
          <div className="sovtrend">
            <p>
              <i
                className="fas fa-fire me-1"
                style={{ color: "var(--secondary)" }}
              />
              Trending Searches
            </p>
            <span className="ttag">Smash Burger</span>
            <span className="ttag">Nashville Chicken</span>
            <span className="ttag">Truffle Pizza</span>
            <span className="ttag">Lava Cake</span>
            <span className="ttag">Loaded Fries</span>
            <span className="ttag">Mango Shake</span>
          </div>
        </div>
      </div>
    </>
  )
}

export default UserHeader